It is a script compatible with UxPlayMIDI. It offer a function almost the same as UxPlayMIDI to RuntimeRevolution and MetaCard. There is a script in "makeSMFLib" button. It is incorporated in the stack-script by 'insert script'.



What is 'UxPlayMIDI'

It is XCMD to expand a Play sentence of HyperTalk. This has a function of play notes , make a MIDI file, and make a QuickTime music movie. Because this depends on MacOS, it don't work in OS X, Windows, and Unix. I confirm that it work with HyperCard/OS7-9 and SuperCard/OS7-9.



Grammar of score

Please refer to "pmd2E.doc" in detail. A basis is a Play sentence of HyperTalk, but it is expanded so that multi-part, chord and some effects are usable. I call this grammar "pmd" in convenience. (a melody format of a certain cellular phone is being unrelated)
'pmd file'  is the text file that the score which conformed to pmd grammar enters. The file which you can edit as a text file


Difference with UxPlayMIDI

Bend (%) and Portament (&) are ignored.
makeSMF can use part to 16. ( <-> UxplayMIDI can use max 32 part )
makeSMF sets 96 with Acoustic (Z) on. ( <-> UxPlayMIDI sets 127 )
makeSMF sets 64 with Pedal (H) on. ( <-> UxPlayMIDI sets 127 )
makeSMF read a Tempo command(T) from only 1st part. It influences all parts.
 ( <-> UxPlayMIDI read each part T-command and influence to each part )


What's 'forMac' file

'forMac' folder is a file for only mac. This is stack for HyperCard, but doesn't work on HyperCard. It is a base to convert it in RunRev or MetaCard. 


What's 'Convert from SMF..' button

This button reads a SMF ( Standart Midi File ) and makes pmd score. It read only an amount of pitch and step-time (gate-time) basically. This function is incomplete, but is usable in input assistance.


System environment

A QuickTIme instrument is necessary to play. Please check "music" from "custom" in QuickTIme installation. ( If you only making file then it is unnecessary. )
I don't understand about Windows and Unix environment. Probably I think that a sound board acts on Windows. In Unix environment, a 'playDestination' property may act effectively.


Other

All 'makeSMF'/'playPmd' scripts are the same as 1.3. The versions 1.3.1, 1.3.2 and 1.3.3 are revised other scripts.

This stack is free to use. All scripts and music data is a public domain. You copy these freely and can change it. But I can bear no duty about this stack.

UDI  2004.02
eudio@chabashira.co.jp
http://member.nifty.ne.jp/UDI/
